package com.example.tigalc;


import android.app.Activity;
import android.os.Bundle;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import android.widget.EditText;



//h klasi mou pou klironomite apo tin Activity kai h opia efarmozi tin Onclick
//listener

public class MainActivity extends Activity implements OnClickListener {

	// setaro ta stihia mou os metavlites stin java shedon panta
	
	  private Button b1;
	
	  private Button b3;
	
	  private Button b5;

	  private Button b7;
	  
	 
	  EditText ss1;
	  
	  EditText ss2;
	  
	  TextView shw;
	  
	  @Override
		protected void onCreate(Bundle savedInstanceState) {
			// TODO Auto-generated method stub
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_main); 
			
			// Setaro tis anafores sta koumpia kai sto stihia
			
			b1 = (Button)findViewById(R.id.btnsum);
			
			b3 = (Button)findViewById(R.id.btnabs);
			 
			b5 = (Button)findViewById(R.id.btnmul);
			
			b7 = (Button)findViewById(R.id.btndiv);
			
		
			ss1 = (EditText)findViewById(R.id.txtbox1);
			
			ss2 = (EditText)findViewById(R.id.txtbox2);
			
			shw = (TextView)findViewById(R.id.lbl1);
					

			// click listeners gia afti tin klasi (this)
			
			b1.setOnClickListener(this);
			b3.setOnClickListener(this);
			b5.setOnClickListener(this);
			b7.setOnClickListener(this);
		
		

		}
	    
		@Override
		// mesa stin methodo onclick tha kano tis sigrisis mou 
		// shetika me ta parapano koumpia pou eftiaxa tous listeners
		// to xero pola sholia ligi ipomoni ime neouli
		
		public void onClick(View v) {
			// TODO Auto-generated method stub
			
			if (v==b1) {
			
			// se afta ta block kodika vriskete h litourgikotita
			// vevea den ine toso sosto na dilonis metavlites eki mesa 
			// alla mages ilikrina eho pola na kano kai den prolaveno
				
				String a,b;
	    		Double vis;
	    		a = ss1.getText().toString();
	    		b = ss2.getText().toString();
	    		vis = Double.parseDouble(a) + Double.parseDouble(b);
	    		shw.setText(vis.toString());
	    		
	    		
	    		    
			}
			
			if (v==b3) {
				
				String a,b;
	    		Double vis;
	    		a = ss1.getText().toString();
	    		b = ss2.getText().toString();
	    		vis = Double.parseDouble(a) - Double.parseDouble(b);
	    		shw.setText(vis.toString());
				
			}
			
			if (v==b5) {
				
				String a,b;
	    		Double vis;
	    		a = ss1.getText().toString();
	    		b = ss2.getText().toString();
	    		vis = Double.parseDouble(a) * Double.parseDouble(b);
	    		shw.setText(vis.toString());
				
			}
			
			if (v==b7) {
				
				String a,b;
	    		Double vis;
	    		a = ss1.getText().toString();
	    		b = ss2.getText().toString();
	    		
	    		if(b.equals("0")){

	        	vis = Double.parseDouble(a) / Double.parseDouble(b);
	    		shw.setText("-99999 error");
	    		 Toast toast=Toast.makeText(this, "diereses me to miden", Toast.LENGTH_LONG);  
	             toast.show();
	            
	             
	             }
	    		else {
	    			
	            vis = Double.parseDouble(a) / Double.parseDouble(b);
	    		shw.setText(vis.toString());
	    		
	    			
	    		}
	    		
				
			}	

	}
			
		}

		


		
	
		








	    
	    




			

	  	  